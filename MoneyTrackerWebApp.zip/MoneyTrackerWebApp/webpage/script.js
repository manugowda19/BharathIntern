document.addEventListener('DOMContentLoaded', function() {
    const transactionForm = document.getElementById('transaction-form');
    const transactionList = document.getElementById('transactions');
    const ctx = document.getElementById('expenseChart').getContext('2d');
    let transactions = [];

    const expenseChart = new Chart(ctx, {
        type: 'line', // Change to 'line' type for line chart
        data: {
            labels: [], // Will be filled with dates from transactions
            datasets: [{
                label: 'Expense Trends',
                data: [], // Will be filled with amounts from transactions
                fill: false,
                borderColor: '#007bff',
                tension: 0.4
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Amount (₹)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                }
            }
        }
    });

    transactionForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const category = document.getElementById('category').value;
        const amount = parseFloat(document.getElementById('amount').value);
        const info = document.getElementById('info').value;
        const date = document.getElementById('date').value;

        const transaction = { category, amount, info, date };
        transactions.push(transaction);
        updateTransactionList();
        updateChart();
        
        transactionForm.reset();
    });

    function updateTransactionList() {
        transactionList.innerHTML = '';
        transactions.forEach(transaction => {
            const transactionItem = document.createElement('li');
            transactionItem.classList.add(transaction.category.toLowerCase());
            transactionItem.innerHTML = `<span>${transaction.info}</span>
                                         <span class="amount">${transaction.category === 'Income' ? '+' : '-'} ₹${transaction.amount}</span>
                                         <span>${transaction.date}</span>`;
            transactionList.appendChild(transactionItem);
        });
    }

    function updateChart() {
        const dates = transactions.map(transaction => transaction.date);
        const amounts = transactions.map(transaction => transaction.amount);

        expenseChart.data.labels = dates;
        expenseChart.data.datasets[0].data = amounts;
        expenseChart.update();
    }
});
