const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/moneytracker', { useNewUrlParser: true, useUnifiedTopology: true });

const transactionSchema = new mongoose.Schema({
    category: String,
    amount: Number,
    info: String,
    date: String
});

const Transaction = mongoose.model('Transaction', transactionSchema);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/transactions', (req, res) => {
    Transaction.find({}, (err, transactions) => {
        if (err) return res.status(500).send(err);
        res.json(transactions);
    });
});

app.post('/api/transactions', (req, res) => {
    const newTransaction = new Transaction(req.body);
    newTransaction.save((err, savedTransaction) => {
        if (err) return res.status(500).send(err);
        res.json(savedTransaction);
    });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
